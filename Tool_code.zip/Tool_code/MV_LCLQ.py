import arcpy
import math
import random
import numpy as np
from scipy.stats import t
import time
import scipy.stats as stats

arcpy.env.overwriteOutput = True
in_features = arcpy.GetParameterAsText(0)
Type = arcpy.GetParameterAsText(1)
Point1 = arcpy.GetParameterAsText(2)
Points = arcpy.GetParameterAsText(3)
simulation_times = int(arcpy.GetParameterAsText(4))
out_features = arcpy.GetParameterAsText(5)
Ps = []
for i in range(len(Points.split(" "))):
    Ps.append(Points.split(" ")[i])
GD_lbq = arcpy.GetParameter(6)
ZSY_lbq = arcpy.GetParameter(8)
K_NEAREST = arcpy.GetParameter(11)

if((GD_lbq == False and ZSY_lbq == False and K_NEAREST == False) or (GD_lbq == True and ZSY_lbq == True and K_NEAREST == True)):
    arcpy.AddMessage("Illegal Pparameters!!!")
    exit()

if(ZSY_lbq):
    Max_Band = arcpy.GetParameterAsText(9)
    count_neighbor = arcpy.GetParameterAsText(10)
    if(Max_Band == "" or count_neighbor == ""):
        arcpy.AddMessage("Missing parameters!!!")
        exit()
if(GD_lbq):
    Band = arcpy.GetParameterAsText(7)
    if(Band == ""):
        arcpy.AddMessage("Missing Parameters!!!")
        exit()
if(K_NEAREST):
    K_NEAREST_COUNT = int(arcpy.GetParameterAsText(12))
    ID_ID = arcpy.GetParameterAsText(13)
    arcpy.AddMessage("K_NEAREST_COUNT:"+str(K_NEAREST_COUNT)+";ID_name:"+str(ID_ID))
    if (K_NEAREST_COUNT == "" or  ID_ID == ""):
        arcpy.AddMessage("Missing Parameters!!!")
        exit()

def Get_pvalue(a, b):
    a.sort()
    i1 = 0
    i2 = 0
    i3 = 0
    l = len(a)
    if(a[l-1]==0):
        return 1
    aa = []
    for i in a:
        if (i < b):
            i1 += 1
        elif (i > b):
            i2 += 1
        else:
            i3 += 1
    if(i1==0 or i2==0):
        aa = a[:]
    else:
        if(i1+i3<i2+i3):
            if(i1+i3<l/2):
                aa = a[0:i1+i3]
                aa.extend(list(np.random.choice(a[i1+i3:l-1],i1+i3,replace=False)))
            else:
                aa = a[:]
        elif(i1+i3>i2+i3):
            if (i2 + i3 < l / 2):
                aa = a[l-i2-i3:l]
                aa.extend(list(np.random.choice(a[0:l-i2-i3-1], i2 + i3, replace=False)))
            else:
                aa = a[:]
        else:
            aa = a[:]
    res = stats.ttest_1samp(aa, b)
    return float(res.pvalue)
workspace = out_features.split("gdb")[0]+"gdb"
arcpy.env.workspace = workspace
Feature_A = out_features
Feature_Other = workspace+'\Feature_Other'
arcpy.Select_analysis(in_features,Feature_A,Type+" = \'"+Point1+"\'")
arcpy.Select_analysis(in_features,Feature_Other,Type+" <> \'"+Point1+"\'")
Count_table = "Count_table"
arcpy.Statistics_analysis(in_features, Count_table, [[Type, "COUNT"]], Type)
Count_A = int(arcpy.GetCount_management(Feature_A).getOutput(0))
Total_Count = int(arcpy.GetCount_management(in_features).getOutput(0))
Sum_weight_Data = []
Other_weight_data = []
for i in range(Count_A):
    Other_weight_data.append([])
    Sum_weight_Data.append(0)
    for p in range(len(Ps)):
        Other_weight_data[i].append(0)
name = ''
for p in Ps:
    name = name+p
Filed_name = Point1+"_"+name+"_LCLQ"
Neartable = "Near_table"
if(GD_lbq):
    arcpy.GenerateNearTable_analysis(Feature_A, Feature_Other, Neartable, str(Band) + " Meters", "NO_LOCATION", "NO_ANGLE", "ALL")
    arcpy.AddField_management(Neartable, "Weight", "FLOAT")
    arcpy.CalculateField_management(Neartable, "Weight", "math.exp(-0.5*math.pow(!NEAR_DIST!,2)/math.pow(" + str(Band) + ",2))","PYTHON_9.3")
    daikuan = Band
    arcpy.JoinField_management(Neartable, "NEAR_FID", Feature_Other, "OBJECTID", [Type])
if(ZSY_lbq):
    arcpy.GenerateNearTable_analysis(Feature_A, Feature_Other, Neartable,str(Max_Band) + " Meters","NO_LOCATION", "NO_ANGLE", "ALL",int(count_neighbor))
    arcpy.AddField_management(Neartable, "Weight", "FLOAT")
    Neartable_maxband = "Neartable_maxband"
    arcpy.Statistics_analysis(Neartable, Neartable_maxband, [["NEAR_DIST", "MAX"]], "IN_FID")
    arcpy.JoinField_management(Neartable, "IN_FID", Neartable_maxband, "IN_FID", ["MAX_NEAR_DIST"])
    arcpy.Delete_management(Neartable_maxband)
    arcpy.CalculateField_management(Neartable, "Weight", "math.exp(-0.5*math.pow(!NEAR_DIST!,2)/math.pow(!MAX_NEAR_DIST!,2))", "PYTHON_9.3")
    arcpy.JoinField_management(Neartable, "NEAR_FID", Feature_Other, "OBJECTID", [Type])
if(K_NEAREST):
    arcpy.Copy_management(in_features, "in_features")
    arcpy.AddXY_management("in_features")
    thiessen = "thiessen"
    arcpy.CreateThiessenPolygons_analysis("in_features", thiessen, "ALL")
    path = "D:\SpatialWeightsMatrixtoTable.swm"
    try:
        arcpy.Delete_management(path)
    except:
        arcpy.AddMessage("No SpatialWeightsMatrixtoTable, don't need delete!!!")
    arcpy.AddMessage("canshu: " + str(thiessen)+ str(ID_ID)+ str(path)+ str(K_NEAREST_COUNT))
    arcpy.GenerateSpatialWeightsMatrix_stats(thiessen, ID_ID, path, "K_NEAREST_NEIGHBORS", "#", "#", "#", K_NEAREST_COUNT, "NO_STANDARDIZATION")
    SpatialWeightsMatrixtoTable = "SpatialWeightsMatrixtoTable"
    arcpy.ConvertSpatialWeightsMatrixtoTable_stats(path, SpatialWeightsMatrixtoTable)
    arcpy.Delete_management(path)
    arcpy.JoinField_management(SpatialWeightsMatrixtoTable, "NID", "in_features", ID_ID, [Type, "POINT_X", "POINT_Y"])
    arcpy.JoinField_management(SpatialWeightsMatrixtoTable, ID_ID, "in_features", ID_ID, [Type, "POINT_X", "POINT_Y"])
    arcpy.AddField_management(SpatialWeightsMatrixtoTable, "NEAR_DIST", "FLOAT")
    arcpy.TableSelect_analysis(SpatialWeightsMatrixtoTable, Neartable, Type + "_1 = '" + Point1 + "'")
    arcpy.Delete_management(SpatialWeightsMatrixtoTable)
    try:
        arcpy.CalculateField_management(Neartable, "NEAR_DIST", 'math.sqrt(math.pow(!POINT_X!-!POINT_X_1!,2)+math.pow(!POINT_Y!-!POINT_Y_1!,2))', "PYTHON_9.3")
    except:
        time.sleep(10)
        arcpy.CalculateField_management(Neartable, "NEAR_DIST", 'math.sqrt(math.pow(!POINT_X!-!POINT_X_1!,2)+math.pow(!POINT_Y!-!POINT_Y_1!,2))', "PYTHON_9.3")
    arcpy.AddField_management(out_features, "IN_FID", "LONG")
    arcpy.AddField_management(Feature_Other, "NEAR_FID", "LONG")
    arcpy.CalculateField_management(out_features, "IN_FID", '!OBJECTID!', "PYTHON_9.3")
    arcpy.CalculateField_management(Feature_Other, "NEAR_FID", '!OBJECTID!', "PYTHON_9.3")
    arcpy.JoinField_management(Neartable, ID_ID, out_features, ID_ID, ["IN_FID"])
    arcpy.JoinField_management(Neartable, "NID", Feature_Other, ID_ID, ["NEAR_FID"])
    arcpy.JoinField_management(Neartable, "NID", out_features, ID_ID, ["IN_FID"])
    codeblock = """def run(a,b):
            if(a):
                return a
            else:
                return b"""
    expression = "run(!IN_FID_1!,!NEAR_FID!)"
    arcpy.CalculateField_management(Neartable, "NEAR_FID", expression, "PYTHON_9.3", codeblock)
    arcpy.DeleteField_management(Neartable, [ID_ID, "NID", "WEIGHT", Type + "_1", "POINT_X", "POINT_Y", "POINT_X_1", "POINT_Y_1", "IN_FID_1"])
    arcpy.AddField_management(Neartable, "Weight", "FLOAT")
    Neartable_maxband = "Neartable_maxband"
    arcpy.Statistics_analysis(Neartable, Neartable_maxband, [["NEAR_DIST", "MAX"]], "IN_FID")
    arcpy.JoinField_management(Neartable, "IN_FID", Neartable_maxband, "IN_FID", ["MAX_NEAR_DIST"])
    arcpy.Delete_management(Neartable_maxband)
    arcpy.Delete_management("in_features")
    arcpy.Delete_management(thiessen)
    arcpy.CalculateField_management(Neartable, "Weight", "math.exp(-0.5*math.pow(!NEAR_DIST!,2)/math.pow(!MAX_NEAR_DIST!,2))", "PYTHON_9.3")
    arcpy.JoinField_management(Neartable, "NEAR_FID", Feature_Other, "OBJECTID", [Type])
Points_type = []
Type_COUNT = []
for row in arcpy.da.SearchCursor(Count_table,[Type,"COUNT_"+Type]):
    if(row[0]!=Point1):
        Points_type.append(row[0])
        Type_COUNT.append(row[1])
Sum_product = 1
for i,p in enumerate(Points_type):
    for p1 in Ps :
        if(p == p1):
            Sum_product = float(Sum_product) * Type_COUNT[i]
LCLQ_denominator = Sum_product/(pow(((Total_Count)-1),int(len(Ps))))
arcpy.AddMessage("LCLQ_denominator:"+str(LCLQ_denominator))
IN_FID = []
NEAR_FID = []
Type_Other = []
WEIGHT = []
for row in arcpy.da.SearchCursor(Neartable,["IN_FID","NEAR_FID",Type,"Weight"]):
    IN_FID.append(row[0])
    NEAR_FID.append(row[1])
    Type_Other.append(row[2])
    WEIGHT.append(row[3])
for i,j in enumerate(IN_FID):
    Sum_weight_Data[j-1] += WEIGHT[i]
    for u,p in enumerate(Ps):
        if(p == Type_Other[i]):
            Other_weight_data[j-1][u] += WEIGHT[i]
LCLQ_Ture = []
for i in range(Count_A):
    LCLQ_value = np.prod(Other_weight_data[i]) / (pow(float(Sum_weight_Data[i]), len(Ps))) / LCLQ_denominator
    LCLQ_Ture.append(LCLQ_value)
arcpy.AddField_management(Feature_A, Filed_name, "FLOAT")
cursor = arcpy.da.UpdateCursor(Feature_A, ["OBJECTID", Filed_name])
for row in cursor:
    row[1] = LCLQ_Ture[row[0]-1]
    cursor.updateRow(row)
if(simulation_times>0):
    other_type = []
    for row in arcpy.da.SearchCursor(Feature_Other,["OBJECTID",Type]):
        other_type.append(row[1])
    LCLQ = []
    for CID in range(simulation_times):
        LCLQ.append([])
        Points_type01 = Points_type[:]
        Type_COUNT01 = Type_COUNT[:]
        other_type_D =other_type[:]
        for i in range(len(Other_weight_data)):
            for j in range(len(Other_weight_data[i])):
                Other_weight_data[i][j] =0
        new_type = []
        while (len(other_type_D)):
            i = random.randint(0, len(other_type_D)-1)
            new_type.append(other_type_D[i])
            del other_type_D[i]
        for i,j in enumerate(NEAR_FID):
            Type_Other[i] = new_type[j-1]
        for i, j in enumerate(IN_FID):
            for ii, p in enumerate(Ps):
                if (p == Type_Other[i]):
                    Other_weight_data[j-1][ii] += WEIGHT[i]
        for i in range(Count_A):
            LCLQ_value = np.prod(Other_weight_data[i]) / (pow(float(Sum_weight_Data[i]), len(Ps))) / LCLQ_denominator
            LCLQ[CID].append(LCLQ_value)
    p_value = []
    for i in range(Count_A):
        s_lclq = []
        for ii in range(simulation_times):
            s_lclq.append(LCLQ[ii][i])
        p_value.append(Get_pvalue(s_lclq,LCLQ_Ture[i]))
    arcpy.AddField_management(Feature_A, "p_value", "FLOAT")
    cursor = arcpy.da.UpdateCursor(Feature_A,["OBJECTID","p_value"])
    for row in cursor:
        row[1] = p_value[row[0]-1]
        cursor.updateRow(row)
    arcpy.Delete_management(Count_table)
    arcpy.Delete_management(Feature_Other)
    arcpy.Delete_management(Neartable)
# arcpy.AddField_management(Feature_A, "MV_LCLQ", "FLOAT")
# codeblock02 = """def run(a,b):
#         if(b>0.05):
#             return -1
#         else:
#             return a"""
# expression02 = "run(!"+Filed_name+"!,!p_value!)"
# arcpy.CalculateField_management(Feature_A, "MV_LCLQ", expression02, "PYTHON_9.3",codeblock02)
arcpy.DeleteField_management(Feature_A, ["IN_FID"])
MLCLQ_global = float((sum(LCLQ_Ture))/float(Count_A))
arcpy.AddMessage("MLCLQ_Global: "+str(MLCLQ_global))